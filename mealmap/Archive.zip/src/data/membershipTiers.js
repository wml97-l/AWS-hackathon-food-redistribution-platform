export const membershipTiers = {
  basic: {
    name: 'Basic',
    color: '#6B6B6B',
    bgColor: '#F5F5F5',
    maxQuantity: 100,
    benefits: [
      'Up to 100 units per request',
      'Weekly request submissions',
      'Basic support'
    ]
  },
  bronze: {
    name: 'Bronze',
    color: '#C4BCB7',
    bgColor: '#FAF8F7',
    maxQuantity: 150,
    benefits: [
      'Up to 150 units per request',
      'Twice-weekly requests',
      'Email support'
    ]
  },
  silver: {
    name: 'Silver',
    color: '#5BC2A8',
    bgColor: '#E5F6F5',
    maxQuantity: 250,
    benefits: [
      'Up to 250 units per request',
      'Daily requests',
      'Priority support',
      'Access to frozen goods'
    ]
  },
  gold: {
    name: 'Gold',
    color: '#FFC425',
    bgColor: '#FFF8E1',
    maxQuantity: 400,
    benefits: [
      'Up to 400 units per request',
      'Unlimited requests',
      'Dedicated account manager',
      'First access to premium items',
      'Emergency supply access'
    ]
  }
};

export const getTierConfig = (tier) => {
  return membershipTiers[tier] || membershipTiers.basic;
};
