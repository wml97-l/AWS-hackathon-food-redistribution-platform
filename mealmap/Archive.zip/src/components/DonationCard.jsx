import './DonationCard.css';

function DonationCard({ donation }) {
  const getDaysUntilExpiry = (bestBefore) => {
    const today = new Date();
    const expiryDate = new Date(bestBefore);
    const diffTime = expiryDate - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const getUrgencyClass = (bestBefore) => {
    const days = getDaysUntilExpiry(bestBefore);
    if (days <= 2) return 'urgent';
    if (days <= 5) return 'warning';
    return 'fresh';
  };

  const getUrgencyLabel = (bestBefore) => {
    const days = getDaysUntilExpiry(bestBefore);
    if (days <= 0) return 'Expired';
    if (days === 1) return '1 day left';
    if (days <= 5) return `${days} days left`;
    return `${days} days`;
  };

  const urgencyClass = getUrgencyClass(donation.bestBefore);

  return (
    <div className={`donation-card ${urgencyClass}`}>
      <div className="card-header">
        <h3 className="item-name">{donation.itemName}</h3>
        <span className={`urgency-badge ${urgencyClass}`}>
          {getUrgencyLabel(donation.bestBefore)}
        </span>
      </div>

      <div className="card-body">
        <div className="info-row">
          <span className="label">Category:</span>
          <span className="value">{donation.category}</span>
        </div>
        <div className="info-row">
          <span className="label">Quantity:</span>
          <span className="value">{donation.quantity} {donation.unit}</span>
        </div>
        <div className="info-row">
          <span className="label">Donor:</span>
          <span className="value donor">{donation.donor}</span>
        </div>
        <div className="info-row">
          <span className="label">Location:</span>
          <span className="value">{donation.location}</span>
        </div>
        <div className="info-row">
          <span className="label">Best Before:</span>
          <span className="value">{new Date(donation.bestBefore).toLocaleDateString('en-GB')}</span>
        </div>
      </div>

      <div className="card-footer">
        {donation.canFreeze && (
          <span className="freeze-badge">Can Freeze</span>
        )}
        <span className="received-date">
          Received: {new Date(donation.receivedDate).toLocaleDateString('en-GB')}
        </span>
      </div>
    </div>
  );
}

export default DonationCard;
