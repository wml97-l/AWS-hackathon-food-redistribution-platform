import { Link, useLocation } from 'react-router-dom';
import './Navbar.css';

function Navbar() {
  const location = useLocation();

  return (
    <nav className="navbar">
      <div className="navbar-brand">
        <Link to="/">
          <span className="logo-icon">🍽️</span>
          <span className="logo-text">MealMap</span>
        </Link>
      </div>
      <div className="navbar-links">
        <Link
          to="/"
          className={location.pathname === '/' ? 'active' : ''}
        >
          Dashboard
        </Link>
        <Link
          to="/donations"
          className={location.pathname === '/donations' ? 'active' : ''}
        >
          Donations
        </Link>
        <Link
          to="/requests"
          className={location.pathname === '/requests' ? 'active' : ''}
        >
          Requests
        </Link>
      </div>
    </nav>
  );
}

export default Navbar;
