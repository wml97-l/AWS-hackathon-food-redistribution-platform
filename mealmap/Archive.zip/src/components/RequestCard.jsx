import { getTierConfig } from '../data/membershipTiers';
import './RequestCard.css';

function RequestCard({ request, showTierDetails = false }) {
  const tierConfig = getTierConfig(request.membershipTier);

  const getStatusClass = (status) => {
    switch (status) {
      case 'fulfilled':
        return 'status-fulfilled';
      case 'partial':
        return 'status-partial';
      default:
        return 'status-pending';
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'fulfilled':
        return 'Fulfilled';
      case 'partial':
        return 'Partial';
      default:
        return 'Pending';
    }
  };

  const getPriorityClass = (priority) => {
    switch (priority) {
      case 'high':
        return 'priority-high';
      case 'medium':
        return 'priority-medium';
      default:
        return 'priority-low';
    }
  };

  const maxAllowed = tierConfig.maxQuantity;

  return (
    <div className={`request-card ${getPriorityClass(request.priority)}`}>
      <div className="card-header">
        <div className="org-info">
          <div className="org-name-row">
            <h3 className="org-name">{request.organization}</h3>
            <span
              className="tier-badge"
              style={{
                backgroundColor: tierConfig.bgColor,
                color: tierConfig.color,
                borderColor: tierConfig.color
              }}
            >
              {tierConfig.name}
            </span>
          </div>
          <span className="location">{request.location}</span>
        </div>
        <div className="badges">
          <span className={`status-badge ${getStatusClass(request.status)}`}>
            {getStatusLabel(request.status)}
          </span>
          <span className={`priority-badge ${getPriorityClass(request.priority)}`}>
            {request.priority.charAt(0).toUpperCase() + request.priority.slice(1)} Priority
          </span>
        </div>
      </div>

      <div className="card-body">
        <div className="items-section">
          <span className="section-label">Items Requested:</span>
          <div className="items-tags">
            {request.itemsRequested.map((item, index) => (
              <span key={index} className="item-tag">{item}</span>
            ))}
          </div>
        </div>

        <div className="info-row">
          <span className="label">Quantity Needed:</span>
          <span className="value">{request.quantityNeeded} units</span>
        </div>

        <div className="info-row">
          <span className="label">Max Allowed:</span>
          <span className="value tier-benefit">{maxAllowed} units</span>
        </div>

        {showTierDetails && (
          <div className="tier-details">
            <div className="info-row">
              <span className="label">Member Since:</span>
              <span className="value">
                {new Date(request.memberSince).toLocaleDateString('en-GB')}
              </span>
            </div>
          </div>
        )}

        {request.notes && (
          <div className="notes">
            <span className="notes-label">Notes:</span>
            <p className="notes-text">{request.notes}</p>
          </div>
        )}
      </div>

      <div className="card-footer">
        <span className="request-date">
          Requested: {new Date(request.requestDate).toLocaleDateString('en-GB')}
        </span>
        {request.quantityNeeded > maxAllowed && (
          <span className="over-limit-warning">
            Exceeds tier limit
          </span>
        )}
      </div>
    </div>
  );
}

export default RequestCard;
