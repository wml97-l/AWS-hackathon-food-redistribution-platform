import { useMemo } from 'react';
import StatCard from '../components/StatCard';
import DonationCard from '../components/DonationCard';
import RequestCard from '../components/RequestCard';
import donations from '../data/donations.json';
import requests from '../data/requests.json';
import { membershipTiers, getTierConfig } from '../data/membershipTiers';
import './Dashboard.css';

function Dashboard() {
  const stats = useMemo(() => {
    const today = new Date();

    const totalDonations = donations.length;
    const totalQuantity = donations.reduce((sum, d) => sum + d.quantity, 0);

    const pendingRequests = requests.filter((r) => r.status === 'pending').length;
    const fulfilledRequests = requests.filter((r) => r.status === 'fulfilled').length;

    const urgentItems = donations.filter((d) => {
      const expiryDate = new Date(d.bestBefore);
      const diffDays = Math.ceil((expiryDate - today) / (1000 * 60 * 60 * 24));
      return diffDays <= 3;
    });

    const categoryCounts = donations.reduce((acc, d) => {
      acc[d.category] = (acc[d.category] || 0) + d.quantity;
      return acc;
    }, {});

    const tierCounts = {
      gold: requests.filter((r) => r.membershipTier === 'gold').length,
      silver: requests.filter((r) => r.membershipTier === 'silver').length,
      bronze: requests.filter((r) => r.membershipTier === 'bronze').length,
      basic: requests.filter((r) => r.membershipTier === 'basic').length,
    };

    const totalMembers = requests.length;

    return {
      totalDonations,
      totalQuantity,
      pendingRequests,
      fulfilledRequests,
      urgentItems,
      categoryCounts,
      tierCounts,
      totalMembers,
    };
  }, []);

  const urgentDonations = useMemo(() => {
    const today = new Date();
    return donations
      .filter((d) => {
        const expiryDate = new Date(d.bestBefore);
        const diffDays = Math.ceil((expiryDate - today) / (1000 * 60 * 60 * 24));
        return diffDays <= 5;
      })
      .sort((a, b) => new Date(a.bestBefore) - new Date(b.bestBefore))
      .slice(0, 4);
  }, []);

  const highPriorityRequests = useMemo(() => {
    const priorityOrder = { high: 0, medium: 1, low: 2 };

    return [...requests]
      .filter((r) => r.status !== 'fulfilled')
      .sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority])
      .slice(0, 3);
  }, []);

  return (
    <div className="dashboard">
      <header className="page-header">
        <h1>Dashboard</h1>
        <p>Overview of food donations and member distribution requests</p>
      </header>

      <section className="stats-grid">
        <StatCard
          title="Total Donations"
          value={stats.totalDonations}
          subtitle={`${stats.totalQuantity.toLocaleString()} units total`}
          icon="📦"
          variant="donations"
        />
        <StatCard
          title="Pending Requests"
          value={stats.pendingRequests}
          subtitle={`${stats.fulfilledRequests} fulfilled this week`}
          icon="📋"
          variant="requests"
        />
        <StatCard
          title="Expiring Soon"
          value={stats.urgentItems.length}
          subtitle="Within 3 days"
          icon="⚠️"
          variant="urgent"
        />
        <StatCard
          title="Member Organizations"
          value={stats.totalMembers}
          subtitle="Active food banks"
          icon="🏢"
          variant="success"
        />
      </section>

      <section className="membership-overview">
        <h2>Membership Tiers</h2>
        <div className="tier-cards">
          {Object.entries(stats.tierCounts).map(([tier, count]) => {
            const config = getTierConfig(tier);
            return (
              <div
                key={tier}
                className="tier-stat-card"
                style={{
                  borderColor: config.color,
                  backgroundColor: config.bgColor
                }}
              >
                <div className="tier-stat-header">
                  <span className="tier-name" style={{ color: config.color }}>
                    {config.name}
                  </span>
                  <span className="tier-count">{count}</span>
                </div>
                <div className="tier-stat-details">
                  <span>Max: {config.maxQuantity} units</span>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <div className="dashboard-columns">
        <section className="urgent-section">
          <div className="section-header">
            <h2>Expiring Soon</h2>
            <span className="badge urgent">Needs Attention</span>
          </div>
          <div className="cards-list">
            {urgentDonations.length > 0 ? (
              urgentDonations.map((donation) => (
                <DonationCard key={donation.id} donation={donation} />
              ))
            ) : (
              <p className="empty-message">No items expiring soon</p>
            )}
          </div>
        </section>

        <section className="priority-section">
          <div className="section-header">
            <h2>High Priority Requests</h2>
            <span className="badge priority">Urgent</span>
          </div>
          <div className="cards-list">
            {highPriorityRequests.length > 0 ? (
              highPriorityRequests.map((request) => (
                <RequestCard key={request.id} request={request} />
              ))
            ) : (
              <p className="empty-message">No pending requests</p>
            )}
          </div>
        </section>
      </div>

      <section className="category-breakdown">
        <h2>Inventory by Category</h2>
        <div className="category-bars">
          {Object.entries(stats.categoryCounts)
            .sort((a, b) => b[1] - a[1])
            .map(([category, count]) => (
              <div key={category} className="category-bar">
                <div className="category-info">
                  <span className="category-name">{category}</span>
                  <span className="category-count">{count} units</span>
                </div>
                <div className="bar-container">
                  <div
                    className="bar-fill"
                    style={{
                      width: `${(count / stats.totalQuantity) * 100}%`,
                    }}
                  />
                </div>
              </div>
            ))}
        </div>
      </section>
    </div>
  );
}

export default Dashboard;
