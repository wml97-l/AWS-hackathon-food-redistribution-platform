import { useState, useMemo } from 'react';
import RequestCard from '../components/RequestCard';
import requests from '../data/requests.json';
import { membershipTiers, getTierConfig } from '../data/membershipTiers';
import './Requests.css';

function Requests() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [locationFilter, setLocationFilter] = useState('all');
  const [tierFilter, setTierFilter] = useState('all');
  const [showTierDetails, setShowTierDetails] = useState(false);

  const locations = useMemo(() => {
    return ['all', ...new Set(requests.map((r) => r.location))];
  }, []);

  const filteredRequests = useMemo(() => {
    let result = [...requests];

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(
        (r) =>
          r.organization.toLowerCase().includes(term) ||
          r.itemsRequested.some((item) => item.toLowerCase().includes(term))
      );
    }

    if (statusFilter !== 'all') {
      result = result.filter((r) => r.status === statusFilter);
    }

    if (priorityFilter !== 'all') {
      result = result.filter((r) => r.priority === priorityFilter);
    }

    if (locationFilter !== 'all') {
      result = result.filter((r) => r.location === locationFilter);
    }

    if (tierFilter !== 'all') {
      result = result.filter((r) => r.membershipTier === tierFilter);
    }

    // Sort by request priority, then by status
    const priorityOrder = { high: 0, medium: 1, low: 2 };
    const statusOrder = { pending: 0, partial: 1, fulfilled: 2 };

    result.sort((a, b) => {
      if (priorityOrder[a.priority] !== priorityOrder[b.priority]) {
        return priorityOrder[a.priority] - priorityOrder[b.priority];
      }
      return statusOrder[a.status] - statusOrder[b.status];
    });

    return result;
  }, [searchTerm, statusFilter, priorityFilter, locationFilter, tierFilter]);

  const statusCounts = useMemo(() => {
    return {
      pending: requests.filter((r) => r.status === 'pending').length,
      partial: requests.filter((r) => r.status === 'partial').length,
      fulfilled: requests.filter((r) => r.status === 'fulfilled').length,
    };
  }, []);

  const tierCounts = useMemo(() => {
    return {
      gold: requests.filter((r) => r.membershipTier === 'gold').length,
      silver: requests.filter((r) => r.membershipTier === 'silver').length,
      bronze: requests.filter((r) => r.membershipTier === 'bronze').length,
      basic: requests.filter((r) => r.membershipTier === 'basic').length,
    };
  }, []);

  return (
    <div className="requests-page">
      <header className="page-header">
        <h1>Food Bank Requests</h1>
        <p>Requests from member organizations across Ireland</p>
      </header>

      <div className="summary-row">
        <div className="status-summary">
          <div className="status-item pending">
            <span className="count">{statusCounts.pending}</span>
            <span className="label">Pending</span>
          </div>
          <div className="status-item partial">
            <span className="count">{statusCounts.partial}</span>
            <span className="label">Partial</span>
          </div>
          <div className="status-item fulfilled">
            <span className="count">{statusCounts.fulfilled}</span>
            <span className="label">Fulfilled</span>
          </div>
        </div>

        <div className="tier-summary">
          {Object.entries(tierCounts).map(([tier, count]) => {
            const config = getTierConfig(tier);
            return (
              <div
                key={tier}
                className="tier-item"
                style={{ borderColor: config.color }}
              >
                <span className="count" style={{ color: config.color }}>{count}</span>
                <span className="label">{config.name}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="tier-benefits-toggle">
        <button
          className={`toggle-btn ${showTierDetails ? 'active' : ''}`}
          onClick={() => setShowTierDetails(!showTierDetails)}
        >
          {showTierDetails ? 'Hide' : 'Show'} Tier Details
        </button>
      </div>

      {showTierDetails && (
        <div className="tier-benefits-panel">
          <h3>Membership Tier Benefits</h3>
          <div className="tiers-grid">
            {Object.entries(membershipTiers).map(([key, tier]) => (
              <div
                key={key}
                className="tier-card"
                style={{ borderColor: tier.color, backgroundColor: tier.bgColor }}
              >
                <h4 style={{ color: tier.color }}>{tier.name}</h4>
                <div className="tier-stats">
                  <div className="stat">
                    <span className="stat-label">Max Quantity</span>
                    <span className="stat-value">{tier.maxQuantity} units</span>
                  </div>
                </div>
                <ul className="benefits-list">
                  {tier.benefits.map((benefit, i) => (
                    <li key={i}>{benefit}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="filters-bar">
        <div className="search-box">
          <input
            type="text"
            placeholder="Search organizations or items..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="filter-group">
          <label htmlFor="tier-filter">Tier:</label>
          <select
            id="tier-filter"
            value={tierFilter}
            onChange={(e) => setTierFilter(e.target.value)}
          >
            <option value="all">All Tiers</option>
            <option value="gold">Gold</option>
            <option value="silver">Silver</option>
            <option value="bronze">Bronze</option>
            <option value="basic">Basic</option>
          </select>
        </div>

        <div className="filter-group">
          <label htmlFor="status-filter">Status:</label>
          <select
            id="status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="partial">Partial</option>
            <option value="fulfilled">Fulfilled</option>
          </select>
        </div>

        <div className="filter-group">
          <label htmlFor="priority-filter">Priority:</label>
          <select
            id="priority-filter"
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
          >
            <option value="all">All Priorities</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>

        <div className="filter-group">
          <label htmlFor="location-filter">Location:</label>
          <select
            id="location-filter"
            value={locationFilter}
            onChange={(e) => setLocationFilter(e.target.value)}
          >
            {locations.map((loc) => (
              <option key={loc} value={loc}>
                {loc === 'all' ? 'All Locations' : loc}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="results-info">
        Showing {filteredRequests.length} of {requests.length} requests
      </div>

      <div className="requests-grid">
        {filteredRequests.length > 0 ? (
          filteredRequests.map((request) => (
            <RequestCard
              key={request.id}
              request={request}
              showTierDetails={showTierDetails}
            />
          ))
        ) : (
          <div className="no-results">
            <p>No requests match your filters</p>
            <button onClick={() => {
              setSearchTerm('');
              setStatusFilter('all');
              setPriorityFilter('all');
              setLocationFilter('all');
              setTierFilter('all');
            }}>
              Clear Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default Requests;
