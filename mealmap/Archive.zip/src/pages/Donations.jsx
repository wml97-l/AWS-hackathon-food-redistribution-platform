import { useState, useMemo } from 'react';
import DonationCard from '../components/DonationCard';
import donations from '../data/donations.json';
import './Donations.css';

function Donations() {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [locationFilter, setLocationFilter] = useState('all');
  const [sortBy, setSortBy] = useState('expiry');

  const categories = useMemo(() => {
    return ['all', ...new Set(donations.map((d) => d.category))];
  }, []);

  const locations = useMemo(() => {
    return ['all', ...new Set(donations.map((d) => d.location))];
  }, []);

  const filteredDonations = useMemo(() => {
    let result = [...donations];

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(
        (d) =>
          d.itemName.toLowerCase().includes(term) ||
          d.donor.toLowerCase().includes(term)
      );
    }

    if (categoryFilter !== 'all') {
      result = result.filter((d) => d.category === categoryFilter);
    }

    if (locationFilter !== 'all') {
      result = result.filter((d) => d.location === locationFilter);
    }

    switch (sortBy) {
      case 'expiry':
        result.sort((a, b) => new Date(a.bestBefore) - new Date(b.bestBefore));
        break;
      case 'quantity':
        result.sort((a, b) => b.quantity - a.quantity);
        break;
      case 'received':
        result.sort((a, b) => new Date(b.receivedDate) - new Date(a.receivedDate));
        break;
      case 'name':
        result.sort((a, b) => a.itemName.localeCompare(b.itemName));
        break;
      default:
        break;
    }

    return result;
  }, [searchTerm, categoryFilter, locationFilter, sortBy]);

  return (
    <div className="donations-page">
      <header className="page-header">
        <h1>Incoming Donations</h1>
        <p>Food items received from supermarket partners</p>
      </header>

      <div className="filters-bar">
        <div className="search-box">
          <input
            type="text"
            placeholder="Search items or donors..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="filter-group">
          <label htmlFor="category-filter">Category:</label>
          <select
            id="category-filter"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat === 'all' ? 'All Categories' : cat}
              </option>
            ))}
          </select>
        </div>

        <div className="filter-group">
          <label htmlFor="location-filter">Location:</label>
          <select
            id="location-filter"
            value={locationFilter}
            onChange={(e) => setLocationFilter(e.target.value)}
          >
            {locations.map((loc) => (
              <option key={loc} value={loc}>
                {loc === 'all' ? 'All Locations' : loc}
              </option>
            ))}
          </select>
        </div>

        <div className="filter-group">
          <label htmlFor="sort-select">Sort by:</label>
          <select
            id="sort-select"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
          >
            <option value="expiry">Expiry Date</option>
            <option value="received">Recently Received</option>
            <option value="quantity">Quantity</option>
            <option value="name">Name</option>
          </select>
        </div>
      </div>

      <div className="results-info">
        Showing {filteredDonations.length} of {donations.length} donations
      </div>

      <div className="donations-grid">
        {filteredDonations.length > 0 ? (
          filteredDonations.map((donation) => (
            <DonationCard key={donation.id} donation={donation} />
          ))
        ) : (
          <div className="no-results">
            <p>No donations match your filters</p>
            <button onClick={() => {
              setSearchTerm('');
              setCategoryFilter('all');
              setLocationFilter('all');
            }}>
              Clear Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default Donations;
